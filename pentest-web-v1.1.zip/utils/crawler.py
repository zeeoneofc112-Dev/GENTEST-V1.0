#!/usr/bin/env python3
"""
Crawler
Pentest-Web v1.1
"""

print("Crawler Utility")
