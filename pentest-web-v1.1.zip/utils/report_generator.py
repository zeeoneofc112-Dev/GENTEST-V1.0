#!/usr/bin/env python3
"""
Report Generator
Pentest-Web v1.1
"""

print("Report Generator Utility")
