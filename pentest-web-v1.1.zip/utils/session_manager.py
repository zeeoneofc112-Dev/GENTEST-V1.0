#!/usr/bin/env python3
"""
Session Manager
Pentest-Web v1.1
"""

print("Session Manager Utility")
