#!/usr/bin/env python3
"""
Param Extractor
Pentest-Web v1.1
"""

print("Param Extractor Utility")
