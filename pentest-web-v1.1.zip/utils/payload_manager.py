#!/usr/bin/env python3
"""
Payload Manager
Pentest-Web v1.1
"""

print("Payload Manager Utility")
